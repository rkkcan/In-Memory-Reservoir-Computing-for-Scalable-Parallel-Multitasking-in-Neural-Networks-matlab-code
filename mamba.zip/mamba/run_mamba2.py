import time

import torch
import torch.nn as nn

from bigptq import BRAGPTQ
from bigptq import BRAGPTQnew
from bigptq import BRAGPTQ64
from binary import Binarization
from modelutils import find_layers
from mamba_ssm.models.mixer_seq_simple import MambaLMHeadModel
from mamba_ssm.models.mixer_seq_simple import MixerModel
from mamba_ssm.modules.block import Block
from smoothquant.smooth import smooth_lm
from smoothquant.fake_quant import quantize_llama_like, quantize_mamba_like
import numpy as np

class Quantizer(nn.Module):
    
    def __init__(self, shape=1):
        super(Quantizer, self).__init__()

    def configure(self, bits, perchannel=False, sym=False, norm=2.4, grid=100, maxshrink=.8, trits=False):

        self.maxq = torch.tensor(2**bits - 1)
        self.perchannel = perchannel
        self.sym = sym
        self.norm = norm
        self.grid = grid
        self.maxshrink = maxshrink
        if trits:
            self.maxq = torch.tensor(-1)
        self.scale = torch.tensor(0)

    def _quantize(self, x, scale, zero, maxq):
        if maxq < 0:
            return (x > scale / 2).float() * scale + (x < zero / 2).float() * zero
        q = torch.clamp(torch.round(x / scale) + zero, 0, maxq)
        # print(q)
        return scale * (q - zero)

    def find_params(self, w, weight=False):
        # perchannel = True
        weight = True
        dev = w.device
        maxq = self.maxq
        scale = torch.zeros(1)
        zero = torch.zeros(1)
        shape = w.shape

        if dev != scale.device:
            scale=scale.to(dev)
            zero=zero.to(dev)
            maxq=maxq.to(dev)

        x = w.clone()

 
        x = x.flatten().unsqueeze(0)
        tmp = torch.zeros(x.shape[0], device=dev)
        xmin = torch.minimum(x.min(1)[0], tmp)
        xmax = torch.maximum(x.max(1)[0], tmp)

        tmp = (xmin == 0) & (xmax == 0)
        xmin[tmp] = -1
        xmax[tmp] = +1
        scale = (xmax - xmin) / maxq
        zero = torch.round(-xmin / scale)
        
        if maxq < 0:
            scale = xmax
            zero = xmin
        else:
            scale = (xmax - xmin) / maxq
            if self.sym:
                zero = torch.full_like(scale, (maxq + 1) / 2)
            else:
                zero = torch.round(-xmin / scale)
        tau_range = 0.1
        tau_n = 50
        # best = torch.zeros_like(x[:, 0], device=dev)
        best = torch.full([1], float('inf'), device=dev)
        _p = torch.ones([1])
        p_left = 1 - tau_range
        p_right = 1 + tau_range
        for p in torch.cat([torch.ones(1),torch.linspace(1.0,p_right,tau_n+1)[1:],torch.linspace(1.0,p_left,tau_n+1)[1:]]):
            xmin1 = p * xmin
            xmax1 = p * xmax
            scale1 = (xmax1 - xmin1) / maxq
            zero1 = torch.round(-xmin1 / scale1) if not self.sym else zero

            # print(x.shape, scale1.shape, zero1.shape, maxq.shape)
            w_q = self._quantize(x, scale1, zero1, maxq)
            # print(w_q.shape, x.shape)
            w_q -= x
            w_q.abs_()
            w_q.pow_(self.norm)
            
            err = torch.sum(w_q, 1)
            tmp = err < best
            if torch.any(tmp):
                _p[tmp] = p
                best[tmp] = err[tmp]
                scale[tmp] = scale1[tmp]
                zero[tmp] = zero1[tmp]

        if weight:
            shape = [-1] + [1] * (len(shape) - 1)
            scale = scale.reshape(shape)
            zero = zero.reshape(shape)

        self.scale = scale
        self.zero = zero
        self.maxq = maxq

    def quantize(self, x):
        return self._quantize(x, self.scale, self.zero, self.maxq)



# As [768,16]  (k * d, d_state)
# Dt_proj_weights [4,192,6] (K=4, N, inner)
# X_proj_weights [4,32,192]  (K=4, inner, rank)
def quantize_ssm(
    w: torch.Tensor,
    k: int=4,
    nbits: int=4,
):
    
    original_shape = w.shape
    if len(w.shape) == 2: # As
        d_state = w.shape[1]
        w = w.view(k, -1, d_state)

    Wq = torch.zeros_like(w)
    Wq = Wq.to(w.device)

    for i in range(k):
        ssm_quantizer = Quantizer()
        ssm_quantizer.configure(nbits)
        ssm_quantizer.find_params(w[i, :, :], weight=True)
        Wq[i, :, :] = ssm_quantizer.quantize(w[i, :, :])

    Wq = Wq.view(original_shape)
    return Wq 


def quantize_ssm_2d(
    w: torch.Tensor,
    k: int=4,
    nbits: int=4,
):
    
    original_shape = w.shape
    
    w = w.view(k, -1)

    Wq = torch.zeros_like(w)
    Wq = Wq.to(w.device)

    for i in range(k):
        ssm_quantizer = Quantizer()
        ssm_quantizer.configure(nbits)
        ssm_quantizer.find_params(w[i, :], weight=True)
        Wq[i, :] = ssm_quantizer.quantize(w[i, :])

    Wq = Wq.view(original_shape)
    return float(Wq)


def quantize_ssm_new(
    w: torch.Tensor,
    nbits: int=4,
):
    
    # original_shape = w.shape
    # if len(w.shape) == 2: # As
    #     d_state = w.shape[1]
    #     w = w.view(k, -1, d_state)

    Wq = torch.zeros_like(w)
    # Wq = Wq.to(w.device)

    ssm_quantizer = Quantizer()
    ssm_quantizer.configure(nbits)
    ssm_quantizer.find_params(w, weight=True)
    Wq = ssm_quantizer.quantize(w)

    # Wq = Wq.view(original_shape)
    return Wq

def get_model(model):
    import torch

    def skip(*args, **kwargs):
        pass

    torch.nn.init.kaiming_uniform_ = skip
    torch.nn.init.uniform_ = skip
    torch.nn.init.normal_ = skip
    device = "cuda"
    dtype = torch.float16
    if "opt" in model:
        from transformers import OPTForCausalLM

        model = OPTForCausalLM.from_pretrained(model, torch_dtype="auto")
        model.seqlen = model.config.max_position_embeddings
    elif "llama" in model:
        from transformers import LlamaForCausalLM

        model = LlamaForCausalLM.from_pretrained(model, torch_dtype="auto")
        model.seqlen = 2048
        
    elif "mamba2" in model:
        # from transformers import MambaConfig, MambaForCausalLM, AutoTokenizer
        # model = MambaForCausalLM.from_pretrained("state-spaces/mamba-2.8b-hf")
        # model = MambaLMHeadModel.from_pretrained("state-spaces/mamba-130m")
        model = MambaLMHeadModel.from_pretrained("state-spaces/mamba2-2.7b", device=device, dtype=dtype)
        # model = MambaLMHeadModel.from_pretrained("state-spaces/mamba2-130m", device=device, dtype=dtype)
        # model = MambaLMHeadModel.from_pretrained("state-spaces/mamba2-1.3b", device=device, dtype=dtype)
        # model = MambaLMHeadModel.from_pretrained("state-spaces/mamba-2.8b-hf", device=device, dtype=dtype)
    return model


'''
The function is employed to calibrate and quantize models layer by layer.
'''
@torch.no_grad()
def quant_sequential(model, dataloader, dev):
    print("Starting ...")

    for name, module in model.named_modules():
        module.global_name = args.model + name

    use_cache = model.config.use_cache
    model.config.use_cache = False

    if "opt" in args.model:
        layers = model.model.decoder.layers
        model.model.decoder.embed_tokens = model.model.decoder.embed_tokens.to(dev)
        model.model.decoder.embed_positions = model.model.decoder.embed_positions.to(
            dev
        )
        if (
            hasattr(model.model.decoder, "project_out")
            and model.model.decoder.project_out
        ):
            model.model.decoder.project_out = model.model.decoder.project_out.to(dev)
        if (
            hasattr(model.model.decoder, "project_in")
            and model.model.decoder.project_in
        ):
            model.model.decoder.project_in = model.model.decoder.project_in.to(dev)
    elif "llama" in args.model:
        layers = model.model.layers
        model.model.embed_tokens = model.model.embed_tokens.to(dev)
        model.model.norm = model.model.norm.to(dev)
    # elif "mamba" in args.model:
    #     layers = model.backbone.layers
    #     model.backbone.embeddings = model.backbone.embeddings.to(dev)
    #     model.backbone.norm_f = model.backbone.norm_f.to(dev)
    elif "mamba2" in args.model:
    # elif "mamba" in args.model:
        layers = model.backbone.layers
        model.backbone.embedding = model.backbone.embedding.to(dev)
        model.backbone.norm_f = model.backbone.norm_f.to(dev)
    layers[0] = layers[0].to(dev)

    dtype = next(iter(model.parameters())).dtype
    # inps = torch.zeros(
    #     (args.nsamples, model.seqlen, model.config.hidden_size), dtype=dtype, device=dev
    # )
    inps = torch.zeros(
        (args.nsamples, 2048, 2560), dtype=dtype, device=dev
    )
    # inps = torch.zeros(
    #     (args.nsamples, 2048, 768), dtype=dtype, device=dev
    # )
    # cache = {"i": 0, "attention_mask": None}
    cache = {"i": 0}

    # class Catcher(nn.Module):
    #     def __init__(self, module):
    #         super().__init__()
    #         self.module = module

    #     def forward(self, inp, **kwargs):
    #         inps[cache["i"]] = inp
    #         cache["i"] += 1
    #         # cache["attention_mask"] = kwargs["attention_mask"]
    #         raise ValueError

    # layers[0] = Catcher(layers[0])
    # for batch in dataloader:
    #     try:
    #         model(batch[0].to(dev))
    #     except ValueError:
    #         pass
    # layers[0] = layers[0].module
    for batch in dataloader:
        inps[cache["i"]] = model.backbone.embedding(batch[0].to(dev))
        cache["i"] += 1
        

    layers[0] = layers[0].cpu()
    if "opt" in args.model:
        model.model.decoder.embed_tokens = model.model.decoder.embed_tokens.cpu()
        model.model.decoder.embed_positions = model.model.decoder.embed_positions.cpu()
        if (
            hasattr(model.model.decoder, "project_out")
            and model.model.decoder.project_out
        ):
            model.model.decoder.project_out = model.model.decoder.project_out.cpu()
        if (
            hasattr(model.model.decoder, "project_in")
            and model.model.decoder.project_in
        ):
            model.model.decoder.project_in = model.model.decoder.project_in.cpu()
    elif "llama" in args.model:
        model.model.embed_tokens = model.model.embed_tokens.cpu()
        model.model.norm = model.model.norm.cpu()
    # elif "mamba" in args.model:
    #     model.backbone.embeddings = model.backbone.embeddings.cpu()
    #     model.backbone.norm_f = model.backbone.norm_f.cpu()
    elif "mamba2" in args.model:
        model.backbone.embedding = model.backbone.embedding.cpu()
        model.backbone.norm_f = model.backbone.norm_f.cpu()
    torch.cuda.empty_cache()

    outs = torch.zeros_like(inps)
    # attention_mask = cache["attention_mask"]

    print("Ready.")
    
    # for name, param in model.named_parameters():
    #     if name.endswith('norm.weight'):
    #         param.data = quantize_ssm_new(param,  nbits=4)
            
    # for name, param in model.named_parameters():
    #     if name.endswith('norm_f.weight'):
    #         param.data = quantize_ssm_new(param,  nbits=4)
    # for name, param in model.named_parameters():
    #     if name.endswith('A_log'):
    #         param.data = quantize_ssm_2d(param, k=param.shape[0], nbits=4)
    # for name, param in model.named_parameters():
    #     if name.endswith('D'):
    #         param.data = quantize_ssm_new(param,  nbits=4)
    # for name, param in model.named_parameters():
    #     if name.endswith('conv1d.weight'):
    #         param.data = quantize_ssm(param, k=param.shape[0], nbits=4)
    # for name, param in model.named_parameters():
    #     if name.endswith('conv1d.bias'):
    #         param.data = quantize_ssm_new(param,  nbits=4)
    # for name, param in model.named_parameters():
    #     if name.endswith('dt_proj.bias'):
    #         param.data = quantize_ssm_new(param,  nbits=3)
    # print("conv and parameters Done!")
    
    
    
    # for i in range(64):
    #     mamba_block = model.backbone.layers[i].mixer
    #     for name, param in mamba_block.named_parameters():
    #         if name == 'in_proj.weight':
    #             x = param[:5120, :]
    #             z = param[5120:, :]
    #             x_q = quantize_ssm_new(x, nbits=8)
    #             z_q = quantize_ssm_new(z, nbits=4)
    #             param.data = torch.cat((x_q, z_q), dim=0)
    #             x_origin = x 
    #             x_new = x_q
    #             # print(param.shape)
            
    #         elif name == 'x_proj.weight':
    #             dt = param[:160, :]
    #             B = param[160:176, :]
    #             C = param[176:, :]
    #             B_origin = B @ x_origin
    #             C_origin = C @ x_origin
    #             dt_q = quantize_ssm_new(dt, nbits=8)
    #             B_q = quantize_ssm_new(B_origin, nbits=4)
    #             C_q = quantize_ssm_new(C_origin, nbits=4)
    #             B_q_new = B_q @ x_new.T
    #             C_q_new = C_q @ x_new.T
    #             param.data = torch.cat((dt_q, B_q_new, C_q_new), dim=0)
    
    # for name, param in model.named_parameters():
    #     if name.endswith('out_proj.weight'):
    #         param.data = quantize_ssm_new(param, nbits=8)
    #         param.data = param.data.to(torch.float16)
    
    # for name, param in model.named_parameters():
    #     if name.endswith('in_proj.weight'):
    #         # x = param[:5120, :]
    #         # z = param[5120:, :]
    #         # x_q = quantize_ssm_new(x, nbits=8)
    #         # z_q = quantize_ssm_new(z, nbits=2)
    #         # param.data = torch.cat((x_q, z_q), dim=0)
    #         # x_origin = x 
    #         # x_new = x_q
    #         # # param.data = quantize_ssm_new(param,  nbits=8)
    #         param.data = quantize_ssm_new(param,  nbits=4)
    #         param.data = param.data.to(torch.float16)
            
    # for name, param in model.named_parameters():
    #     if name.endswith('x_proj.weight'):
    #         dt = param[:160, :]
    #         B = param[160:176, :]
    #         C = param[176:, :]
    #         dt_q = quantize_ssm_new(dt, nbits=8)
    #         B_q = quantize_ssm_new(B, nbits=4)
    #         C_q = quantize_ssm_new(C, nbits=4)
    #         param.data = torch.cat((dt_q, B_q, C_q), dim=0)
    #         # param.data = quantize_ssm_new(param,  nbits=8)
    # for name, param in model.named_parameters():
    #     if name.endswith('dt_proj.weight'):
    #         # dt = param[:160, :]
    #         # B = param[160:176, :]
    #         # C = param[176:, :]
    #         # dt_q = quantize_ssm_new(dt, nbits=4)
    #         # B_q = quantize_ssm_new(B, nbits=4)
    #         # C_q = quantize_ssm_new(C, nbits=4)
    #         # param.data = torch.cat((dt_q, B_q, C_q), dim=0)
    #         param.data = quantize_ssm_new(param,  nbits=3)
    
    
    # for i in range(64):
    #     mamba_block = model.backbone.layers[i].mixer
    #     for name, param in mamba_block.named_parameters():
    #         if name == 'in_proj.weight':
    #             param = param[:, :400][:400, :]
    #             # param = quantize_ssm_new(param, nbits=4)
                
                
    #             # noise = torch.normal(mean=0, std=0.01 * param.abs())
    #             # param += noise
                
    #             # np.savetxt(f'layer1/int8/origin1000_noise1.txt', param.cpu().detach().numpy())
    #             # for i in range(1, 11):  # Loop from 1 to 10 for noise levels
    #             #     noise_std = 0.01 * i  # Generate noise standard deviation from 0.01 to 0.1
    #             #     noise = torch.normal(mean=0, std=noise_std * param.abs())
    #             #     noisy_param = param + noise
            
    #         # Save the noisy parameter with a modified filename
    #             filename = f'matrix400/layer{i}.txt' 
    #             np.savetxt(filename, param.cpu().detach().numpy())
                
                
                
                
                
                
                # with open(f'origin.txt', 'w') as f:
                # # 将参数转换为 NumPy 数组并保存为字符串
                #     f.write(param.cpu().detach().numpy())
                # print(param.shape)
                # break

    # list = [0, 1, 2, 3, 4, 5, 11, 12, 13, 14, 15, 16, 17, 18, 21, 23, 24, 25, 27, 28, 29, 30, 40, 42, 43, 45, 48, 49, 51, 53, 55, 56]
    list = [0, 18, 28, 17, 13, 15, 21, 49, 3, 25, 56, 23, 40, 42, 51, 55] 
    # list = [0, 18, 28, 17, 13, 15, 21, 49]        
    # for i in range(64):
    #     mamba_block = model.backbone.layers[i].mixer
    #     if i in list:
    #         for name, param in mamba_block.named_parameters():
    #             if name == 'in_proj.weight':
    #                 # print(param.shape)
    #                 dt = param[:5120, :]
    #                 B = param[5120:10496, :]
    #                 C = param[10496:, :]
    #                 dt_q = quantize_ssm_new(dt, nbits=5)
    #                 B_q = quantize_ssm_new(B, nbits=5)
    #                 C_q = quantize_ssm_new(C, nbits=5)
    #                 param.data = torch.cat((dt_q, B_q, C_q), dim=0)
    #                 # noise = torch.normal(mean=0, std=0.1 * param.abs())
    #                 # param.data += noise
    #                 param.data = param.data.to(torch.float16)
    #     else:
    #         for name, param in mamba_block.named_parameters():
    #             if name == 'in_proj.weight':
    #                 # print(param.shape)
    #                 dt = param[:5120, :]
    #                 B = param[5120:10496, :]
    #                 C = param[10496:, :]
    #                 dt_q = quantize_ssm_new(dt, nbits=4)
    #                 B_q = quantize_ssm_new(B, nbits=4)
    #                 C_q = quantize_ssm_new(C, nbits=4)
    #                 param.data = torch.cat((dt_q, B_q, C_q), dim=0)
    #                 # noise = torch.normal(mean=0, std=0.1 * param.abs())
    #                 # param.data += noise
    #                 param.data = param.data.to(torch.float16)
                    
                    
                # dt_origin = dt
                # dt_new = dt_q
                # print(param.shape)
            
            # elif name == 'out_proj.weight':
            #     # print(1)
            #     param = quantize_ssm_new(param, nbits=8)

            #     param.data = param.data.to(torch.float16)
            
            
    for i in range(64):
        mamba_block = model.backbone.layers[i].mixer
        for name, param in mamba_block.named_parameters():
            if name == 'in_proj.weight':
                param.data = quantize_ssm_new(param, nbits=6)
                param.data = param.data.to(torch.float16)
            elif name == 'out_proj.weight':
                param.data = quantize_ssm_new(param, nbits=6)
                param.data = param.data.to(torch.float16)
                    
                
            
    print("x_proj and in_porj Done!")
    data_dict = {}

    
    # for i in range(len(layers)):
    #     layer = layers[i].to(dev)
    #     print(layer)

    #     subset = find_layers(layer)
    #     print(subset)
        
    #     # del subset['mixer.x_proj']
    #     # del subset['mixer.dt_proj']
    #     # del subset['mixer.in_proj']
    #     # print(subset)

    #     gptq = {}
    #     for name in subset:
    #         if (
    #             not (args.minlayer <= i < args.maxlayer and args.quant_only in name)
    #         ) == (not args.invert):
    #             continue
    #         if name == 'mixer.out_proj':
    #             braq_quantizer = Binarization(
    #                     subset[name].weight,
    #                     method=args.low_quant_method,
    #                     groupsize=groupsize,
    #                 )
    #             gptq[name] = BRAGPTQ(
    #                     subset[name],
    #                     braq_quantizer,
    #                     salient_metric=args.salient_metric,
    #                     disable_gptq=args.disable_gptq,
    #                 )
    #         else:
    #             braq_quantizer = Binarization(
    #                 subset[name].weight,
    #                 method=args.low_quant_method,
    #                 groupsize=128,
    #             )
    #             gptq[name] = BRAGPTQnew(
    #                 subset[name],
    #                 braq_quantizer,
    #                 salient_metric=args.salient_metric,
    #                 disable_gptq=args.disable_gptq,
    #             )

    #     def add_batch(name):
    #         def tmp(_, inp, out):
    #             gptq[name].add_batch(inp[0].data, out.data)

    #         return tmp

    #     handles = []
    #     for name in gptq:
    #         handles.append(subset[name].register_forward_hook(add_batch(name)))
    #     if i == 0:
    #         rs1 = [None] * args.nsamples
    #         rs2 = [None] * args.nsamples
    #     for j in range(args.nsamples):
    #         # outs[j] = layer(inps[j].unsqueeze(0), attention_mask=attention_mask)[0]
    #         outs[j], rs1[j] = layer(inps[j].unsqueeze(0), rs1[j])
    #     for h in handles:
    #         h.remove()

    #     for name in gptq:
    #         print(i, name)
    #         print("Quantizing ...")
    #         info = gptq[name].fasterquant(
    #             percdamp=args.percdamp, 
    #             blocksize=args.blocksize,
    #         )
    #         gptq[name].free()
            
    #         key = f"{i}.{name}"  # 创建键
    #         data_dict[key] = info  # 将info作为值存入字典
        
    #         # with open('mamba_salient_channel_smooth.txt', 'a') as log_file:
    #         #     log_file.write(f"{i}, {name}, {info}\n")


    #     for j in range(args.nsamples):
    #         # outs[j] = layer(inps[j].unsqueeze(0), attention_mask=attention_mask)[0]
    #         outs[j], rs2[j] = layer(inps[j].unsqueeze(0), rs2[j])

    #     layers[i] = layer.cpu()
    #     del layer
    #     del gptq
    #     torch.cuda.empty_cache()

    #     inps, outs, rs1 = outs, inps, rs2

    # # torch.save(data_dict, 'mamba_salient_channel_origin.pt')
    # model.config.use_cache = use_cache


if __name__ == "__main__":
    import argparse
    from datautils import *

    def list_of_ints(arg):
        return list(map(int, arg.split(',')))
    
    def list_of_floats(arg):
        return list(map(float, arg.split(',')))

    parser = argparse.ArgumentParser()

    parser.add_argument(
        "model", type=str, help="model to load; for example `huggyllama/llama-7b`."
    )
    parser.add_argument(
        "dataset",
        type=str,
        choices=["wikitext2", "ptb", "c4"],
        help="Where to extract calibration data from.",
    )
    parser.add_argument(
        "low_quant_method",
        type=str,
        choices=["xnor", "sign", "no", "2bit", "4bit", "prune", "braq"],
        help="quantization method; `xnor` is the method using XNOR to adapt hardware calculation; `prune` is the method used in sparseGPTQ; braq is the method used in BiLLM",
    )
    parser.add_argument("--load_quantized", action="store_true")
    parser.add_argument(
        "--seed", type=int, default=0, help="Seed for sampling the calibration data."
    )
    parser.add_argument(
        "--nsamples", type=int, default=128, help="Number of calibration data samples."
    )
    parser.add_argument(
        "--percdamp",
        type=float,
        default=0.01,
        help="Percent of the average Hessian diagonal to use for dampening.",
    )
    parser.add_argument(
        "--blocksize",
        type=int,
        default=128,
        help="Blocksize to use for adaptive mask selection.",
    )
    parser.add_argument(
        "--salient_metric",
        type=str,
        default="magnitude",
        choices=["magnitude", "hessian"],
    )
    parser.add_argument(
        "--device",
        type=str,
        default="cuda:0",
        help="set the device to use for quantization.",
    )
    parser.add_argument(
        "--disable_gptq",
        action="store_true",
        help="disable GPTQ for quantization.",
    )
    parser.add_argument(
        "--minlayer", type=int, default=-1, help="Quant all layers with id >= this."
    )
    parser.add_argument(
        "--maxlayer", type=int, default=1000, help="Quant all layers with id < this."
    )
    parser.add_argument(
        "--quant_only",
        type=str,
        default="",
        help="Quant only layers that contain this text.",
    )
    parser.add_argument("--invert", action="store_true", help="Invert subset.")
    parser.add_argument(
        "--save",
        action="store_true",
    )
    parser.add_argument(
        "--log_wandb", action="store_true", help="Whether to log to wandb."
    )

    args = parser.parse_args()
    groupsize = args.blocksize

    device = args.device
    save_title = f"{args.model}_{args.dataset}_{args.low_quant_method}_{groupsize}_{args.salient_metric}"
    save_file = "./output/" + save_title.replace("/", "_") + ".pt"
    
    # model = get_model(save_file)
    # print(model)
    # print(model.config.hidden_size)
    # model.eval()
    # for i in range(12, 32, 2):  # 70到99，对应0.70到0.99
    #     i = i/10
    if args.load_quantized:
        model = get_model(save_file)
        model.eval()
    else: # braq
        model = get_model(args.model)
        model.eval()
        tick = time.time()
        # dataloader, testloader = get_loaders(
        #     args.dataset,
        #     nsamples=args.nsamples,
        #     seed=args.seed,
        #     model=args.model,
        #     seqlen=model.seqlen,
        # )
        dataloader, testloader = get_loaders(
            args.dataset,
            nsamples=args.nsamples,
            seed=args.seed,
            model=args.model,
            seqlen=2048,
        )
        print(model)
        # for name, module in model.named_modules():
        #     if isinstance(module, Block):
        #         in_norm = module.norm
        #         print(module.norm.weight)
        #         out_norm = module.mixer.norm
        #         print(module.mixer.norm.weight)
        #         print(name)
        # layers = model.backbone.layers[0].mixer.in_proj
        # print(layers.weight)
        
        # act_scales = torch.load("/home/zijian/projects/BiLLM/mamba2-2.7b.pt")
        # index = torch.load("/home/zijian/projects/BiLLM/mamba_salient_channel_origin.pt")
        # smooth_lm(model, act_scales, index, 2,0.6)
        # model = quantize_mamba_like(model)
        print("done")
        # layers = model.backbone.layers[0].mixer.in_proj
        # print(layers.weight)
        # model = quantize_mamba_like(model)
        # for name, param in model.named_parameters():
        #     print(name)
        
        for name, param in model.named_parameters():
            if name.endswith('in_proj.weight'):   
                noise = torch.normal(mean=0, std=0.01 * param.abs())
                param.data += noise
                # print("111")
        for name, param in model.named_parameters():
            if name.endswith('out_proj.weight'):   
                noise = torch.normal(mean=0, std=0.01 * param.abs())
                param.data += noise
        quant_sequential(model, dataloader, device)
        print("quantization time:", time.time() - tick, "s")
        # noisenumber = 0.1
        # for name, param in model.named_parameters():
        #     if name.endswith('in_proj.weight'):   
        #         # print(param.max())
        #         stdnew = param.abs() + 0.1 * (param.max() - param.min())
        #         noise = torch.normal(mean=0, std=noisenumber * stdnew.abs())
        #         param.data += noise
        #         # print("111")
        # for name, param in model.named_parameters():
        #     if name.endswith('out_proj.weight'):   
        #         stdnew = param.abs() + 0.1 * (param.max() - param.min())
        #         noise = torch.normal(mean=0, std=noisenumber * stdnew.abs())
        #         param.data += noise

    if args.save:
        save_path = os.path.dirname(save_file)
        if not os.path.exists(save_path):
            os.makedirs(save_path)
        model.save_pretrained(save_file)
    result = []
    for dataset in ["wikitext2", "ptb", "c4"]:
        dataloader, testloader = get_loaders(
            dataset, seed=args.seed, seqlen=2048, model=args.model
        )
    # for dataset in ["c4"]:
    #     dataloader, testloader = get_loaders(
    #         dataset, seed=args.seed, seqlen=2048, model=args.model
    #     )   
        print(dataset)
        if "opt" in args.model:
            from eval_ppl_utils import opt_eval

            opt_eval(model, testloader, device, dataset, args.log_wandb)
        elif "llama" in args.model:
            from eval_ppl_utils import llama_eval

            llama_eval(model, testloader, device, dataset, args.log_wandb)
        elif "mamba2" in args.model:
            from eval_ppl_utils import mamba2_eval

            ppl = mamba2_eval(model, testloader, device, dataset, args.log_wandb)
            result.append(ppl)
            # elif "mamba" in args.model:
            #     from eval_ppl_utils import mamba_eval

            #     mamba_eval(model, testloader, device, dataset, args.log_wandb)
            
        # with open('mamba_wosmooth_channel_scale.txt', 'a') as log_file:
        #             log_file.write(f"{i}, {result}\n")